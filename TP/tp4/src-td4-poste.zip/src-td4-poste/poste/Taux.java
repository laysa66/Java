package poste;

public enum Taux {
	faible, moyen, fort;
}
