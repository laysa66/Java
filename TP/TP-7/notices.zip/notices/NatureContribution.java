package notices;

public enum NatureContribution {
redaction, traduction, redactionPreface, illustration;
}
