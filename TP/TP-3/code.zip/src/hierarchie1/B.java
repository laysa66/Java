package hierarchie1;

public class B extends A {
	public void m1() {}
	public void m2() {}
	public void m3() {}
}
