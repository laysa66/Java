package hierarchie1;

public class C extends A {
	public void m1() {}
	public void m3() {}
}
