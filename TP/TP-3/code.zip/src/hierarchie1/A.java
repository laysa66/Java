package hierarchie1;

public class A {
	public void m0() {}
	public void m1() {}
}
